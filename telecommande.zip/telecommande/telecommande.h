#include <stdint.h>
#include <stdbool.h>


//////////////////////////////////////////////////////////////////////////
//        TELECOMMANDE INFRA-ROUGE
//////////////////////////////////////////////////////////////////////////
#define KEY_A         69
#define KEY_B         70
#define KEY_C         71
#define KEY_D         68
#define KEY_E         67
#define KEY_F         13
#define KEY_UP        64
#define KEY_DOWN      25
#define KEY_RIGHT      9
#define KEY_LEFT       7
#define KEY_SETTINGS  21
#define KEY_0         22
#define KEY_1         12
#define KEY_2         24
#define KEY_3         94
#define KEY_4          8
#define KEY_5         28
#define KEY_6         90
#define KEY_7         66
#define KEY_8         82
#define KEY_9         74

void telecommandeInit();
uint8_t telecommandeTouche(unsigned char r);
void telecommandeRead();



//////////////////////////////////////////////////////////////////////////
//        BOUTON
//////////////////////////////////////////////////////////////////////////
/*
 * mBot est équipé d'un bouton connecté à A7. Cette fonction permet de lire l'état logique (HIGH ou LOW)
 * du bouton. Lorsqu'il n'est pas enfoncé, son état est HIGH.
 */
bool litBouton();
